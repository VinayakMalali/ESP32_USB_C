*PADS-LIBRARY-PART-TYPES-V9*

FTS-103-01-F-S FTS10301FS I CON 9 1 0 0 0
TIMESTAMP 2026.07.09.11.32.55
"Manufacturer_Name" SAMTEC
"Manufacturer_Part_Number" FTS-103-01-F-S
"Mouser Part Number" 200-FTS10301FS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Samtec/FTS-103-01-F-S?qs=0lQeLiL1qyY2ZIwL%2FvO8pg%3D%3D
"Arrow Part Number" FTS-103-01-F-S
"Arrow Price/Stock" https://www.arrow.com/en/products/fts-103-01-f-s/samtec
"Description" Conn Unshrouded Header HDR 3 POS 1.27mm Solder ST Top Entry Thru-Hole Bulk
"Datasheet Link" http://suddendocs.samtec.com/prints/fts-1xx-xx-xx-xx-xx-mkt.pdf
"Geometry.Height" 3.91mm
GATE 1 3 0
FTS-103-01-F-S
1 0 U 1
2 0 U 2
3 0 U 3

*END*
*REMARK* SamacSys ECAD Model
967251/2106419/2.50/3/4/Connector
