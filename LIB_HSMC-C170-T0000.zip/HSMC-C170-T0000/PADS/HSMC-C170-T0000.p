*PADS-LIBRARY-PART-TYPES-V9*

HSMC-C170-T0000 LEDC2012X90N I DIO 9 1 0 0 0
TIMESTAMP 2026.07.15.04.30.45
"Manufacturer_Name" Avago Technologies
"Manufacturer_Part_Number" HSMC-C170-T0000
"Mouser Part Number" 630-HSMC-C170-T0000
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Broadcom-Avago/HSMC-C170-T0000?qs=tMOYG%252Bw4%252BLzMj4CbVjYqsw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Standard LEDs - SMD Top Mt AlInGaP Red
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/HSMC-C170-T0000.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
HSMC-C170-T0000
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
768108/2106419/2.50/2/0/LED
