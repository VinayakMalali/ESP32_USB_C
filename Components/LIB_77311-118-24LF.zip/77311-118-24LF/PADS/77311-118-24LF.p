*PADS-LIBRARY-PART-TYPES-V9*

77311-118-24LF 7731111824LF I CON 9 1 0 0 0
TIMESTAMP 2026.07.09.10.54.11
"Manufacturer_Name" Amphenol Communications Solutions
"Manufacturer_Part_Number" 77311-118-24LF
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" BergStik<sup></sup>, Board to Board connector, Unshrouded vertical Header, Through Hole, Single Row, 24 Positions, 2.54 mm Pitch.
"Datasheet Link" https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/77311.pdf
"Geometry.Height" 8.58mm
GATE 1 24 0
77311-118-24LF
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20
21 0 U 21
22 0 U 22
23 0 U 23
24 0 U 24

*END*
*REMARK* SamacSys ECAD Model
18784460/2106419/2.50/24/2/Connector
