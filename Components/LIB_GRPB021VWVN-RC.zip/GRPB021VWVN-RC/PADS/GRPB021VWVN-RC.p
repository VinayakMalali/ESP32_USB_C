*PADS-LIBRARY-PART-TYPES-V9*

GRPB021VWVN-RC HDRV2W40P0X127_1X2_254X214X400P I CON 9 1 0 0 0
TIMESTAMP 2026.07.09.12.06.25
"Manufacturer_Name" Sullins
"Manufacturer_Part_Number" GRPB021VWVN-RC
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" CONN HEADER .050" 2POS PCB GOLD
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA21/2082060.pdf
"Geometry.Height" 4mm
GATE 1 2 0
GRPB021VWVN-RC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
564369/2106419/2.50/2/4/Connector
